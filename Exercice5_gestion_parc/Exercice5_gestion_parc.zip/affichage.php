<?php // Dispatcher secondaire 
// On inclut le fichier commun
 require('common.php'); 
 $controller->affiche();// action du controleur
 ?>