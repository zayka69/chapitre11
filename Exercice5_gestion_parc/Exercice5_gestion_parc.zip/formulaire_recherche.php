<?php // Dispatcher secondaire 
require('common.php');  
$controller->formulaire_recherche(); // action du controleur
?>