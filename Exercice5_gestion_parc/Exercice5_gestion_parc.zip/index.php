<?php // Dispatcher principal 
require('common.php'); 
$controller->index(); // action du controleur 
?>