<?php // Dispatcher secondaire 
require('common.php'); 
 $controller->recherche(""); //action du controleur
 ?>