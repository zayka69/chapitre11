<body> 
<h2> Selection d'une machine dans le domaine</h2> 
<form name="formip" method="post" action="<?php echo WEBROOT; ?>recherche.php"> <p>Adresse IP commen�ant par:</p>
 <p><input name="addip" size="15" maxlength="15" type="text"></p>
 <p><input value="rechercher" type="submit"></p> 
 </form> 
</body>