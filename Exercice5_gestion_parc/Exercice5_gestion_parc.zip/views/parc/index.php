<h2> <a href="<?php echo WEBROOT; ?>liste.php">Liste</a> </h2>
 <h2> <a href="<?php echo WEBROOT; ?>formulaire_recherche.php">Recherche</a> </h2>
 <h2> <a href="<?php echo WEBROOT; ?>affichage.php">Affichage du graphique</a> </h2>